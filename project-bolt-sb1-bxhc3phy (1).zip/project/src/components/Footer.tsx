import { Mail, Phone, MapPin } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="backdrop-blur-lg bg-white border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-6 py-12 md:py-16">
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          <div>
            <h3 className="text-xl md:text-2xl font-bold mb-3 md:mb-4 text-gray-900">Jeesivustot</h3>
            <p className="text-sm md:text-base text-gray-600 leading-relaxed">
              Luomme ammattitaitoisia verkkosivuja, jotka kasvattavat liiketoimintaasi.
            </p>
          </div>

          <div>
            <h4 className="text-base md:text-lg font-semibold mb-3 md:mb-4 text-gray-900">Sivut</h4>
            <div className="space-y-2 md:space-y-3">
              {[
                { name: 'Etusivu', page: 'home' },
                { name: 'Palvelut', page: 'services' },
                { name: 'Meistä', page: 'about' },
                { name: 'Yhteystiedot', page: 'contact' }
              ].map((item) => (
                <button
                  key={item.page}
                  onClick={() => onNavigate(item.page)}
                  className="block text-sm md:text-base text-gray-600 hover:text-gray-900 transition-colors duration-300"
                >
                  {item.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-base md:text-lg font-semibold mb-3 md:mb-4 text-gray-900">Palvelut</h4>
            <div className="space-y-2 md:space-y-3 text-sm md:text-base text-gray-600">
              <p>Verkkosivujen Suunnittelu</p>
              <p>Räätälöity Kehitys</p>
              <p>SEO-optimointi</p>
              <p>Ylläpito</p>
            </div>
          </div>

          <div>
            <h4 className="text-base md:text-lg font-semibold mb-3 md:mb-4 text-gray-900">Yhteystiedot</h4>
            <div className="space-y-2 md:space-y-3">
              <div className="flex items-center gap-2 md:gap-3 text-sm md:text-base text-gray-600">
                <Phone className="w-4 h-4 md:w-5 md:h-5" />
                <span>+358 45 649 5367</span>
              </div>
              <div className="flex items-center gap-2 md:gap-3 text-sm md:text-base text-gray-600">
                <Mail className="w-4 h-4 md:w-5 md:h-5" />
                <span>jeesivustot@gmail.com</span>
              </div>
              <div className="flex items-center gap-2 md:gap-3 text-sm md:text-base text-gray-600">
                <MapPin className="w-4 h-4 md:w-5 md:h-5" />
                <span>Kankaanpää, Suomi</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 md:mt-12 pt-6 md:pt-8 border-t border-gray-200 text-center text-sm md:text-base text-gray-600">
          <p>&copy; 2025 Jeesivustot. Kaikki oikeudet pidätetään.</p>
        </div>
      </div>
    </footer>
  );
}
