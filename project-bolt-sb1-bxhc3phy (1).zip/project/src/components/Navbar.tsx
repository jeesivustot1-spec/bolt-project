import { Menu, X } from 'lucide-react';
import { useState } from 'react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { name: 'Etusivu', page: 'home' },
    { name: 'Palvelut', page: 'services' },
    { name: 'Meistä', page: 'about' },
    { name: 'Yhteystiedot', page: 'contact' }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-lg bg-white/95 border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16 md:h-20">
          <button
            onClick={() => onNavigate('home')}
            className="text-xl md:text-2xl font-bold text-gray-900 transition-all duration-300 hover:scale-105"
          >
            Jeesivustot
          </button>

          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => onNavigate(item.page)}
                className={`text-sm lg:text-base font-semibold transition-all duration-300 hover:-translate-y-0.5 ${
                  currentPage === item.page
                    ? 'text-gray-900 border-b-2 border-gray-900'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {item.name}
              </button>
            ))}
            <button
              onClick={() => onNavigate('contact')}
              className="px-4 lg:px-6 py-2 bg-gray-900 text-white rounded-lg text-sm lg:text-base font-semibold transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 active:scale-95"
            >
              Aloita Projekti
            </button>
          </div>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 text-gray-900 transition-all duration-300 hover:bg-gray-100 rounded-lg"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden backdrop-blur-lg bg-white/95 border-b border-gray-200">
          <div className="px-6 py-4 space-y-3">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => {
                  onNavigate(item.page);
                  setIsMenuOpen(false);
                }}
                className={`block w-full text-left px-4 py-3 rounded-lg font-semibold transition-all duration-300 ${
                  currentPage === item.page
                    ? 'bg-gray-900 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {item.name}
              </button>
            ))}
            <button
              onClick={() => {
                onNavigate('contact');
                setIsMenuOpen(false);
              }}
              className="block w-full px-4 py-3 bg-gray-900 text-white rounded-lg font-semibold transition-all duration-300 active:scale-95"
            >
              Aloita Projekti
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
