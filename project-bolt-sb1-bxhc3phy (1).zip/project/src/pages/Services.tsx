import { Code, Palette, Search, Wrench, Smartphone, Zap } from 'lucide-react';
import { useState } from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

function BackgroundImage({ src, alt }: { src: string; alt: string }) {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <>
      {!isLoaded && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200 animate-pulse" />
      )}
      <img
        src={src}
        alt={alt}
        className={`w-full h-full object-cover blur-sm transition-opacity duration-500 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
        loading="lazy"
        onLoad={() => setIsLoaded(true)}
      />
    </>
  );
}

export default function Services({ onNavigate }: { onNavigate?: (page: string) => void }) {
  const heroTitleAnim = useScrollAnimation({ threshold: 0.3 });
  const heroDescAnim = useScrollAnimation({ threshold: 0.3 });

  const services = [
    {
      icon: Palette,
      title: 'Verkkosivujen Suunnittelu',
      description: 'Luomme visuaalisesti upeita ja käyttäjäystävällisiä suunnitelmia, jotka heijastavat brändiäsi ja puhuttelevat kohdeyleisöäsi.',
      features: ['Moderni UI/UX', 'Responsiivinen suunnittelu', 'Brändäys'],
      direction: 'left',
      delay: '0.3s'
    },
    {
      icon: Code,
      title: 'Räätälöity Kehitys',
      description: 'Rakennamme tehokkaita, skaalautuvia verkkosovelluksia uusimmilla teknologioilla täyttääksemme ainutlaatuiset liiketoimintavaatimuksesi.',
      features: ['React & TypeScript', 'Suorituskyky-optimointi', 'Puhdas koodi'],
      direction: 'right',
      delay: '0.4s'
    },
    {
      icon: Search,
      title: 'SEO-optimointi',
      description: 'Parannamme verkkosivustosi näkyvyyttä hakukoneissa todistettujen SEO-strategioiden ja parhaiden käytäntöjen avulla.',
      features: ['Avainsanatutkimus', 'Tekninen SEO', 'Sisältöstrategia'],
      direction: 'left',
      delay: '0.6s'
    },
    {
      icon: Wrench,
      title: 'Ylläpito ja Tuki',
      description: 'Tarjoamme jatkuvaa ylläpitoa, päivityksiä ja teknistä tukea pitääksemme verkkosivustosi turvallisena ja ajan tasalla.',
      features: ['24/7 seuranta', 'Säännölliset päivitykset', 'Nopea tuki'],
      direction: 'right',
      delay: '0.8s'
    },
    {
      icon: Smartphone,
      title: 'Mobiilioptimiointi',
      description: 'Varmistamme, että verkkosivustosi toimii täydellisesti kaikilla laitteilla ja näyttökoon koilla.',
      features: ['Mobile-first', 'Kosketusnäytön tuki', 'Nopea lataus'],
      direction: 'left',
      delay: '1.0s'
    },
    {
      icon: Zap,
      title: 'Suorituskyvyn Optimointi',
      description: 'Nopeutamme verkkosivustoasi paremmalle käyttäjäkokemukselle ja korkeammille hakukonesijoituksille.',
      features: ['Koodin optimointi', 'Kuvien pakkaus', 'Välimuistitallennus'],
      direction: 'right',
      delay: '1.2s'
    }
  ];

  return (
    <div className="min-h-screen">
      <section className="relative py-20 md:py-32 px-6 overflow-hidden">
        <div className="absolute inset-0">
          <BackgroundImage
            src="https://images.pexels.com/photos/531880/pexels-photo-531880.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Modern technology and development workspace"
          />
          <div className="absolute inset-0 bg-white/70"></div>
          <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-gray-50 to-transparent"></div>
        </div>
        <div className="relative z-10 max-w-6xl mx-auto text-center">
          <div className="bg-white border border-gray-200 rounded-3xl p-6 md:p-12 inline-block shadow-lg">
            <div ref={heroTitleAnim.ref}>
              <h1
                className={`text-3xl md:text-6xl font-bold text-gray-900 mb-6 transition-all duration-700 ${
                  heroTitleAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
              >
                Palvelumme
              </h1>
            </div>
            <div ref={heroDescAnim.ref}>
              <p
                className={`text-base md:text-xl text-gray-600 max-w-2xl transition-all duration-700 ${
                  heroDescAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
              >
                Kattavat verkkokehitysratkaisut liiketoimintasi kasvattamiseen
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto space-y-6 md:space-y-12">
          {services.map((service, index) => (
            <ServiceCard key={index} service={service} />
          ))}
        </div>
      </section>

      <CTASection onNavigate={onNavigate} />
    </div>
  );
}

function ServiceCard({ service }: { service: typeof services[0] }) {
  const cardAnim = useScrollAnimation({ threshold: 0.2 });

  return (
    <div ref={cardAnim.ref}>
      <div
        className={`bg-white border border-gray-200 rounded-2xl md:rounded-3xl p-6 md:p-12 shadow-lg transition-all duration-700 hover:shadow-2xl hover:scale-[1.02] ${
          cardAnim.isVisible ? 'opacity-100 translate-x-0' : `opacity-0 ${service.direction === 'left' ? '-translate-x-20' : 'translate-x-20'}`
        }`}
      >
        <div className="grid md:grid-cols-[auto,1fr] gap-6 md:gap-8 items-start">
          <div className="w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center transition-all duration-300 hover:scale-110 hover:rotate-6 hover:shadow-xl">
            <service.icon className="w-8 h-8 md:w-10 md:h-10 text-gray-700" />
          </div>

          <div>
            <h3 className="text-xl md:text-3xl font-bold text-gray-900 mb-4">{service.title}</h3>
            <p className="text-sm md:text-lg text-gray-700 mb-6 leading-relaxed">{service.description}</p>

            <div className="flex flex-wrap gap-3">
              {service.features.map((feature, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1.5 md:px-4 md:py-2 bg-gray-100 text-gray-700 rounded-lg text-xs md:text-sm font-medium"
                >
                  {feature}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CTASection({ onNavigate }: { onNavigate?: (page: string) => void }) {
  const ctaAnim = useScrollAnimation({ threshold: 0.3 });

  return (
    <section className="py-12 md:py-24 px-6 bg-white">
      <div className="max-w-4xl mx-auto text-center">
        <div ref={ctaAnim.ref}>
          <div
            className={`bg-gray-50 border border-gray-200 rounded-2xl md:rounded-3xl p-6 md:p-12 shadow-lg transition-all duration-700 ${
              ctaAnim.isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
            }`}
          >
            <h2 className="text-2xl md:text-5xl font-bold text-gray-900 mb-4 md:mb-6">
              Aloitetaan Projektisi
            </h2>
            <p className="text-base md:text-xl text-gray-700 mb-6 md:mb-8">
              Valmis viemään verkkosivustosi seuraavalle tasolle? Olemme täällä auttamassa.
            </p>
            <button
              onClick={() => onNavigate?.('contact')}
              className="w-full sm:w-auto px-8 py-4 bg-gray-900 text-white rounded-xl font-semibold text-lg transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 active:scale-95"
            >
              Ota Yhteyttä
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
