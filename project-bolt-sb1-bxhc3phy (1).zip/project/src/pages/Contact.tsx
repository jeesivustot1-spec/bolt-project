import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

function BackgroundImage({ src, alt }: { src: string; alt: string }) {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <>
      {!isLoaded && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200 animate-pulse" />
      )}
      <img
        src={src}
        alt={alt}
        className={`w-full h-full object-cover blur-sm transition-opacity duration-500 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
        loading="lazy"
        onLoad={() => setIsLoaded(true)}
      />
    </>
  );
}

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export default function Contact() {
  const heroTitleAnim = useScrollAnimation({ threshold: 0.3 });
  const heroDescAnim = useScrollAnimation({ threshold: 0.3 });
  const formAnim = useScrollAnimation({ threshold: 0.2 });
  const contactInfoAnim = useScrollAnimation({ threshold: 0.2 });
  const hoursAnim = useScrollAnimation({ threshold: 0.2 });
  const responseAnim = useScrollAnimation({ threshold: 0.2 });

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { error } = await supabase
        .from('contact_submissions')
        .insert([
          {
            name: formData.name,
            email: formData.email,
            message: formData.message
          }
        ]);

      if (error) {
        console.error('Supabase error:', error);
        alert('Virhe viestin lähetyksessä. Yritä uudelleen.');
      } else {
        setShowSuccess(true);
        setFormData({ name: '', email: '', message: '' });
        setTimeout(() => setShowSuccess(false), 5000);

        try {
          const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-contact-email`;
          await fetch(apiUrl, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
          });
        } catch (emailError) {
          console.log('Email notification failed, but form submission saved:', emailError);
        }
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Virhe viestin lähetyksessä. Yritä uudelleen.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactInfo = [
    {
      icon: Phone,
      title: 'Puhelin',
      value: '045 649 5367',
      delay: '0.2s'
    },
    {
      icon: Mail,
      title: 'Sähköposti',
      value: 'jeesivustot@gmail.com',
      delay: '0.3s'
    },
    {
      icon: MapPin,
      title: 'Sijainti',
      value: 'Kankaanpää 38700',
      delay: '0.4s'
    }
  ];

  return (
    <div className="min-h-screen">
      <section className="relative py-20 md:py-32 px-6 overflow-hidden">
        <div className="absolute inset-0">
          <BackgroundImage
            src="https://images.pexels.com/photos/1438072/pexels-photo-1438072.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Natural landscape with trees and flowing water"
          />
          <div className="absolute inset-0 bg-white/70"></div>
          <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-gray-50 to-transparent"></div>
        </div>
        <div className="relative z-10 max-w-6xl mx-auto text-center">
          <div className="bg-white border border-gray-200 rounded-3xl p-6 md:p-12 inline-block shadow-lg">
            <div ref={heroTitleAnim.ref}>
              <h1
                className={`text-3xl md:text-6xl font-bold text-gray-900 mb-6 transition-all duration-700 ${
                  heroTitleAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
              >
                Ota Yhteyttä
              </h1>
            </div>
            <div ref={heroDescAnim.ref}>
              <p
                className={`text-base md:text-xl text-gray-600 max-w-2xl transition-all duration-700 ${
                  heroDescAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
              >
                Kerro meille projektistasi – vastaamme pian
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-8 md:gap-12">
          <div ref={formAnim.ref}>
            <div
              className={`bg-white border border-gray-200 rounded-2xl md:rounded-3xl p-6 md:p-12 shadow-lg transition-all duration-700 ${
                formAnim.isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-20'
              }`}
            >
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6 md:mb-8">Lähetä Viesti</h2>

              {showSuccess && (
                <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl">
                  <p className="text-green-800 font-semibold text-center">
                    Kiitos yhteydenotostasi, vastaamme mahdollisimman pian!
                  </p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4 md:space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">
                    Nimi
                  </label>
                  <input
                    type="text"
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 bg-white border border-gray-300 text-gray-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-gray-400 transition-all duration-300"
                    placeholder="Nimesi"
                    required
                    disabled={isSubmitting}
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                    Sähköposti
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 bg-white border border-gray-300 text-gray-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-gray-400 transition-all duration-300"
                    placeholder="sähköpostisi@esimerkki.fi"
                    required
                    disabled={isSubmitting}
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2">
                    Viesti
                  </label>
                  <textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={6}
                    className="w-full px-4 py-3 bg-white border border-gray-300 text-gray-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-gray-400 transition-all duration-300 resize-none"
                    placeholder="Kerro meille projektistasi..."
                    required
                    disabled={isSubmitting}
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="group w-full px-8 py-4 bg-gray-900 text-white rounded-xl font-semibold text-lg transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 active:scale-95 relative overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0"
                >
                  <span className="relative z-10 flex items-center justify-center gap-2">
                    {isSubmitting ? 'Lähetetään...' : 'Lähetä Viesti'}
                    <Send className="w-5 h-5 transition-transform group-hover:translate-x-1" />
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-gray-800 to-gray-900 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </button>
              </form>
            </div>
          </div>

          <div className="space-y-6 md:space-y-8">
            <div ref={contactInfoAnim.ref}>
              <div
                className={`bg-white border border-gray-200 rounded-2xl md:rounded-3xl p-6 md:p-12 shadow-lg transition-all duration-700 ${
                  contactInfoAnim.isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'
                }`}
              >
                <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6 md:mb-8">Yhteystiedot</h2>

                <div className="space-y-4 md:space-y-6">
                  {contactInfo.map((info, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-4 p-4 rounded-xl transition-all duration-300 hover:bg-gray-50"
                    >
                      <div className="w-12 h-12 bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 hover:scale-110 hover:shadow-lg">
                        <info.icon className="w-6 h-6 text-gray-700" />
                      </div>
                      <div>
                        <h3 className="text-sm md:text-base font-semibold text-gray-900 mb-1">{info.title}</h3>
                        <p className="text-sm md:text-base text-gray-700">{info.value}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div ref={hoursAnim.ref}>
              <div
                className={`bg-white border border-gray-200 rounded-2xl md:rounded-3xl p-6 md:p-8 shadow-lg transition-all duration-700 ${
                  hoursAnim.isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'
                }`}
              >
                <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-3 md:mb-4">Tavoitettavuus</h3>
                <p className="text-sm md:text-base text-gray-700 leading-relaxed">
                  Meidät tavoittaa parhaiten kello 10-24
                </p>
              </div>
            </div>

            <div ref={responseAnim.ref}>
              <div
                className={`bg-white border border-gray-200 rounded-2xl md:rounded-3xl p-6 md:p-8 shadow-lg transition-all duration-700 ${
                  responseAnim.isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'
                }`}
              >
                <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-3 md:mb-4">Vastaamme Nopeasti</h3>
                <p className="text-sm md:text-base text-gray-700 leading-relaxed">
                  Vastaamme kaikkiin yhteydenottoihin yleensä viikon jokaisena päivänä.
                  Kiireellisissä asioissa voit soittaa suoraan puhelinnumeroomme.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
