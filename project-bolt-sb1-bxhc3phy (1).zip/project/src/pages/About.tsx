import { Heart, Target, Users, Award } from 'lucide-react';
import { useState } from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

function BackgroundImage({ src, alt }: { src: string; alt: string }) {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <>
      {!isLoaded && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200 animate-pulse" />
      )}
      <img
        src={src}
        alt={alt}
        className={`w-full h-full object-cover blur-sm transition-opacity duration-500 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
        loading="lazy"
        onLoad={() => setIsLoaded(true)}
      />
    </>
  );
}

export default function About({ onNavigate }: { onNavigate?: (page: string) => void }) {
  const heroTitleAnim = useScrollAnimation({ threshold: 0.3 });
  const heroDescAnim = useScrollAnimation({ threshold: 0.3 });
  const storyAnim = useScrollAnimation({ threshold: 0.2 });
  const valuesTitleAnim = useScrollAnimation({ threshold: 0.3 });
  const teamTitleAnim = useScrollAnimation({ threshold: 0.3 });
  const ctaAnim = useScrollAnimation({ threshold: 0.3 });

  const team = [
    { name: 'Jimi Laaksonen', role: '', delay: '0.2s' },
    { name: 'Erdem Bulut', role: '', delay: '0.4s' },
    { name: 'Eppu Helkamäki', role: '', delay: '0.6s' }
  ];

  const values = [
    {
      icon: Heart,
      title: 'Intohimo',
      description: 'Rakastamme sitä mitä teemme ja se näkyy jokaisessa projektissa',
      delay: '0.2s'
    },
    {
      icon: Target,
      title: 'Täsmällisyys',
      description: 'Huomiota jokaiseen yksityiskohtaan laadun varmistamiseksi',
      delay: '0.3s'
    },
    {
      icon: Users,
      title: 'Yhteistyö',
      description: 'Työskentelemme tiiviisti asiakkaidemme kanssa',
      delay: '0.4s'
    },
    {
      icon: Award,
      title: 'Erinomaisuus',
      description: 'Pyrimme huippuosaamiseen kaikessa mitä teemme',
      delay: '0.5s'
    }
  ];

  return (
    <div className="min-h-screen">
      <section className="relative py-20 md:py-32 px-6 overflow-hidden">
        <div className="absolute inset-0">
          <BackgroundImage
            src="https://images.pexels.com/photos/1261728/pexels-photo-1261728.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Professional workspace with laptop and coffee"
          />
          <div className="absolute inset-0 bg-white/70"></div>
          <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-white to-transparent"></div>
        </div>
        <div className="relative z-10 max-w-6xl mx-auto text-center">
          <div className="bg-white border border-gray-200 rounded-3xl p-6 md:p-12 inline-block shadow-lg">
            <div ref={heroTitleAnim.ref}>
              <h1
                className={`text-3xl md:text-6xl font-bold text-gray-900 mb-6 transition-all duration-700 ${
                  heroTitleAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
              >
                Meistä
              </h1>
            </div>
            <div ref={heroDescAnim.ref}>
              <p
                className={`text-base md:text-xl text-gray-600 max-w-2xl transition-all duration-700 ${
                  heroDescAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
              >
                Intohimoinen tiimi, joka rakentaa digitaalisia kokemuksia
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24 px-6 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <div ref={storyAnim.ref}>
            <div
              className={`bg-white border border-gray-200 rounded-2xl md:rounded-3xl p-6 md:p-12 shadow-lg transition-all duration-700 ${
                storyAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              <div className="space-y-6 md:space-y-8 text-base md:text-xl text-gray-700 leading-relaxed font-medium">
                <p>
                  Olemme kolme nuorta miestä Kankaanpäästä, joita yhdistää intohimo teknologiaan, yrittäjyyteen ja yhdessä tekemiseen. Perustimme oman yrityksen, joka keskittyy nettisivujen suunnitteluun ja toteutukseen eri alojen yrityksille.
                </p>
                <p>
                  Tavoitteenamme on luoda selkeitä, toimivia ja näyttäviä verkkosivustoja, jotka tukevat asiakkaidemme liiketoimintaa. Meille tärkeitä arvoja ovat rehellisyys, laatu ja sujuva yhteistyö – tuomme tuoretta näkökulmaa digimaailmaan, Kankaanpäästä käsin.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <div ref={valuesTitleAnim.ref}>
            <h2
              className={`text-3xl md:text-5xl font-bold text-center text-gray-900 mb-12 md:mb-16 transition-all duration-700 ${
                valuesTitleAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              Meidän Arvomme
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {values.map((value, index) => (
              <ValueCard key={index} value={value} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div ref={teamTitleAnim.ref}>
            <h2
              className={`text-3xl md:text-5xl font-bold text-center text-gray-900 mb-12 md:mb-16 transition-all duration-700 ${
                teamTitleAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              Tiimimme
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 max-w-4xl mx-auto">
            {team.map((member, index) => (
              <TeamMember key={index} member={member} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24 px-6 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <div ref={ctaAnim.ref}>
            <div
              className={`bg-gray-50 border border-gray-200 rounded-2xl md:rounded-3xl p-6 md:p-12 shadow-lg transition-all duration-700 ${
                ctaAnim.isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
              }`}
            >
              <h2 className="text-2xl md:text-5xl font-bold text-gray-900 mb-4 md:mb-6">
                Tehdään Jotain Mahtavaa Yhdessä
              </h2>
              <p className="text-base md:text-xl text-gray-700 mb-6 md:mb-8">
                Olemme innoissamme mahdollisuudesta työskennellä kanssasi
              </p>
              <button
                onClick={() => onNavigate?.('contact')}
                className="group w-full sm:w-auto px-8 py-4 bg-gray-900 text-white rounded-xl font-semibold text-lg transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 active:scale-95"
              >
                Ota Yhteyttä
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function ValueCard({ value }: { value: typeof values[0] }) {
  const cardAnim = useScrollAnimation({ threshold: 0.2 });

  return (
    <div ref={cardAnim.ref}>
      <div
        className={`bg-white border border-gray-200 rounded-2xl p-6 md:p-8 text-center transition-all duration-700 hover:shadow-2xl hover:-translate-y-2 ${
          cardAnim.isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
        }`}
      >
        <div className="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl flex items-center justify-center mx-auto mb-6 transition-all duration-300 hover:scale-110 hover:rotate-12 hover:shadow-xl">
          <value.icon className="w-8 h-8 text-gray-700" />
        </div>
        <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-3">{value.title}</h3>
        <p className="text-sm md:text-base text-gray-600 leading-relaxed">{value.description}</p>
      </div>
    </div>
  );
}

function TeamMember({ member }: { member: typeof team[0] }) {
  const memberAnim = useScrollAnimation({ threshold: 0.2 });

  return (
    <div ref={memberAnim.ref}>
      <div
        className={`group bg-white border border-gray-200 rounded-2xl overflow-hidden transition-all duration-700 hover:shadow-2xl hover:-translate-y-2 ${
          memberAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20'
        }`}
      >
        <div className="aspect-square bg-gradient-to-br from-gray-100 to-gray-200 relative overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <Users className="w-24 h-24 text-gray-600" />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-gray-300/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        </div>
        <div className="p-4 md:p-6 text-center">
          <h3 className="text-lg md:text-xl font-bold text-gray-900">{member.name}</h3>
        </div>
      </div>
    </div>
  );
}
