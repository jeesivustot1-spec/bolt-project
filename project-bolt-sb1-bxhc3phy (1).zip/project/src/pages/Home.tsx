import { ArrowRight, Code, Palette, Search, Wrench, Award, Lightbulb, Headphones } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

function BackgroundImage({ src, alt }: { src: string; alt: string }) {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <>
      {!isLoaded && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200 animate-pulse" />
      )}
      <img
        src={src}
        alt={alt}
        className={`w-full h-full object-cover blur-sm transition-opacity duration-500 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
        loading="lazy"
        onLoad={() => setIsLoaded(true)}
      />
    </>
  );
}

interface HomeProps {
  onNavigate?: (page: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <div className="min-h-screen">
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <BackgroundImage
            src="https://images.pexels.com/photos/933054/pexels-photo-933054.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Snowy mountain landscape with clear blue sky"
          />
          <div className="absolute inset-0 bg-white/40"></div>
          <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-white to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
          <h1
            className={`text-4xl md:text-7xl font-bold text-gray-900 mb-6 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            style={{ transitionDelay: '0.3s' }}
          >
            Ammattimaiset Verkkosivut
            <br />
            <span className="text-gray-700">Kasvattavat Liiketoimintaasi</span>
          </h1>

          <div
            className={`mb-8 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            style={{ transitionDelay: '0.35s' }}
          >
            <p className="text-xl md:text-3xl font-semibold text-gray-800 tracking-wide">
              Erotu verkossa
            </p>
          </div>

          <p
            className={`text-lg md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            style={{ transitionDelay: '0.4s' }}
          >
            Suunnittelemme ja rakennamme korkealaatuisia, räätälöityjä verkkosivuja
            kaikenkokoisille yrityksille.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={() => onNavigate?.('contact')}
              className={`group relative w-full sm:w-auto px-8 py-4 bg-gray-900 text-white rounded-xl font-semibold text-lg overflow-hidden transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 active:scale-95 ${
                isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
              }`}
              style={{ transitionDelay: '0.5s' }}
            >
              <span className="relative z-10 flex items-center gap-2">
                Aloita Tästä
                <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-gray-800 to-gray-900 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>

            <button
              onClick={() => onNavigate?.('services')}
              className={`group w-full sm:w-auto px-8 py-4 bg-white text-gray-900 rounded-xl font-semibold text-lg border-2 border-gray-300 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:bg-gray-50 active:scale-95 ${
                isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
              }`}
              style={{ transitionDelay: '0.6s' }}
            >
              <span className="flex items-center gap-2">
                Katso Palveluja
                <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
              </span>
            </button>
          </div>
        </div>

      </section>

      <section className="py-12 md:py-24 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <ServicesSection />

        </div>
      </section>

      <WhyChooseUsSection />
    </div>
  );
}

function ServicesSection() {
  const titleAnim = useScrollAnimation({ threshold: 0.3 });
  const card1Anim = useScrollAnimation({ threshold: 0.2 });
  const card2Anim = useScrollAnimation({ threshold: 0.2 });
  const card3Anim = useScrollAnimation({ threshold: 0.2 });
  const card4Anim = useScrollAnimation({ threshold: 0.2 });

  const services = [
    { icon: Palette, title: 'Verkkosivujen Suunnittelu', desc: 'Upeat, käyttäjäystävälliset suunnitelmat', anim: card1Anim },
    { icon: Code, title: 'Räätälöity Kehitys', desc: 'Mukautetut ratkaisut tarpeisiisi', anim: card2Anim },
    { icon: Search, title: 'SEO-optimointi', desc: 'Parempi näkyvyys hakukoneissa', anim: card3Anim },
    { icon: Wrench, title: 'Ylläpito', desc: 'Jatkuva tuki ja päivitykset', anim: card4Anim }
  ];

  return (
    <>
      <div ref={titleAnim.ref}>
        <h2 className={`text-3xl md:text-5xl font-bold text-center text-gray-900 mb-12 md:mb-16 transition-all duration-700 ${
          titleAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}>
          Palvelumme
        </h2>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
        {services.map((service, index) => (
          <div key={index} ref={service.anim.ref}>
            <div
              className={`group bg-white border border-gray-200 rounded-2xl p-6 md:p-8 transition-all duration-700 hover:shadow-2xl hover:-translate-y-2 ${
                service.anim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20'
              }`}
            >
              <div className="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl flex items-center justify-center mb-6 transition-all duration-300 group-hover:scale-110 group-hover:shadow-lg">
                <service.icon className="w-8 h-8 text-gray-700" />
              </div>
              <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
              <p className="text-sm md:text-base text-gray-600 leading-relaxed">{service.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

function WhyChooseUsSection() {
  const titleAnim = useScrollAnimation({ threshold: 0.3 });
  const card1Anim = useScrollAnimation({ threshold: 0.2 });
  const card2Anim = useScrollAnimation({ threshold: 0.2 });
  const card3Anim = useScrollAnimation({ threshold: 0.2 });

  const items = [
    { icon: Lightbulb, title: 'Asiantuntemus', desc: 'Kokemus modernista verkkokehityksestä', anim: card1Anim },
    { icon: Award, title: 'Laatu', desc: 'Tuotantovalmis koodi ja upeat suunnitelmat', anim: card2Anim },
    { icon: Headphones, title: 'Tuki', desc: 'Aina valmiina auttamaan sinua', anim: card3Anim }
  ];

  return (
    <section className="py-12 md:py-24 px-6 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div ref={titleAnim.ref}>
          <h2 className={`text-3xl md:text-5xl font-bold text-center text-gray-900 mb-12 md:mb-16 transition-all duration-700 ${
            titleAnim.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}>
            Miksi Valita Meidät?
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-8 md:gap-12">
          {items.map((item, index) => (
            <div key={index} ref={item.anim.ref}>
              <div
                className={`text-center transition-all duration-700 ${
                  item.anim.isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
                }`}
              >
                <div className="w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full mx-auto mb-6 flex items-center justify-center transition-all duration-300 hover:scale-110 hover:shadow-2xl">
                  <item.icon className="w-10 h-10 text-gray-700" />
                </div>
                <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-4">{item.title}</h3>
                <p className="text-sm md:text-base text-gray-600 leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
